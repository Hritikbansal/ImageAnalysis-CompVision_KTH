
%Question 1
figure(1)
subplot(4,2,1)
fftwave(5,9)

%figure(2)
subplot(4,2,2)
fftwave(9,5)
saveas(2,"q2.png")

%figure(3)
subplot(4,2,3)
fftwave(17,9)

%figure(4)
subplot(4,2,4)
fftwave(17,121)

%figure(5)
subplot(4,2,5)
fftwave(5,1)

%figure(6)
subplot(4,2,6)
fftwave(125,1)

%figure(7)
subplot(4,2,7)
fftwave(120,64)  %Question 6
saveas (7, "figure1.png");


subplot(4,2,8)
fftwave(35,64)  %Question 6

