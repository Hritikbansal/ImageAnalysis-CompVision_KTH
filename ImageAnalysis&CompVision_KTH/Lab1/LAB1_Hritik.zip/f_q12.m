%Testng Rotation exercise for different angles

figure(1);
q12(30);
saveas(1,"q12_30.png");

figure(2);
q12(45);
saveas(2,"q12_45.png");

figure(3);
q12(60);
saveas(3,"q12_60.png");

figure(4);
q12(90);
saveas(4,"q12_90.png");

