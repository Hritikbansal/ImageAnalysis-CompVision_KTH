F = [zeros(48, 128); ones(32, 128); zeros(48, 128)] .* ...
[zeros(128, 60) ones(128, 8) zeros(128, 60)];

figure(1);
showgrey(abs(F));


figure(2);
Fhat=fft2(F);
showfs(Fhat);



