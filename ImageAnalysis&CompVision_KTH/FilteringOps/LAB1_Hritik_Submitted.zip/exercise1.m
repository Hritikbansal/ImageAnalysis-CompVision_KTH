
%Question 1
figure(1)
fftwave(5,9)

figure(2)
fftwave(9,5)

figure(3)
fftwave(17,9)

figure(4)
fftwave(17,121)

figure(5)
fftwave(5,1)

figure(6)
fftwave(125,1)

figure(7)
fftwave(120,64)  %Question 6

figure(8)
fftwave(35,64)  %Question 6
